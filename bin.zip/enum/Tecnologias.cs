﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabajoAgustin
{
    public enum Tecnologias
    {
        React=1, Angular, Vue_js
    }
    public enum Plataformas
    {

        ios=1,android,windowsphone
    }
}
